const mongoose = require("mongoose");

const competitionSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: { type: String, required: true },
  category: { type: String, default: "general" }, // String category instead of ObjectId reference
  deadline: { type: Date, required: true },
  prizes: { type: String, required: true },
  registrationCount: { type: Number, default: 0 }
}, { timestamps: true });

module.exports = mongoose.model("Competition", competitionSchema);
