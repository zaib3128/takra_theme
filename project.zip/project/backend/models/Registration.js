const mongoose = require("mongoose");

const registrationSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  competition: { type: mongoose.Schema.Types.ObjectId, ref: "Competition" },
  status: { type: String, default: "pending" }
}, { timestamps: true });

module.exports = mongoose.model("Registration", registrationSchema);
