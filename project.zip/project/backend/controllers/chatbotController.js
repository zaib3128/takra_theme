const OpenAI = require("openai");

let openai;
if (process.env.DUMMY_OPENAI !== "true") {
  openai = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY
  });
}

exports.chatbot = async (req, res) => {
  try {
    const { message } = req.body;

    // --- DUMMY MODE ---
    if (process.env.DUMMY_OPENAI === "true") {
      const dummyReply = `You said: "${message}". This is a dummy response for free testing during the competition.`;
      return res.json({ reply: dummyReply });
    }

    // --- REAL OPENAI CALL ---
    const completion = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: "You are Taakra competition assistant. Help users about competitions, registration, deadlines and support."
        },
        {
          role: "user",
          content: message
        }
      ]
    });

    res.json({
      reply: completion.choices[0].message.content
    });

  } catch (error) {
    console.error(error);

    // fallback to dummy response if OpenAI fails
    const fallbackReply = `You said: "${req.body.message}". AI is temporarily unavailable, using dummy response.`;
    res.json({ reply: fallbackReply });
  }
};
