const Competition = require("../models/Competition");
const Registration = require("../models/Registration");
const User = require("../models/User");
const Category = require("../models/Category");


// ➤ Add Competition
exports.addCompetition = async (req, res) => {
  try {
    const { title, description, category, deadline, prizes } = req.body;

    // Validation
    if (!title || !description || !deadline || !prizes) {
      return res.status(400).json({ 
        message: "Missing required fields: title, description, deadline, prizes" 
      });
    }

    const competition = await Competition.create({
      title,
      description,
      category: category || "general", // Store category as string if not an ObjectId
      deadline: new Date(deadline),
      prizes
    });

    res.status(201).json(competition);
  } catch (err) {
    console.error("Error creating competition:", err);
    res.status(500).json({ 
      message: "Failed to create competition", 
      error: err.message 
    });
  }
};


// ➤ Update Competition
exports.updateCompetition = async (req, res) => {
  try {
    const { id } = req.params;
    if (!id) return res.status(400).json({ message: "Competition ID required" });

    const competition = await Competition.findByIdAndUpdate(
      id,
      req.body,
      { new: true, runValidators: true }
    );

    if (!competition) {
      return res.status(404).json({ message: "Competition not found" });
    }

    res.json(competition);
  } catch (err) {
    console.error("Error updating competition:", err);
    res.status(500).json({ message: "Failed to update competition", error: err.message });
  }
};


// ➤ Delete Competition
exports.deleteCompetition = async (req, res) => {
  try {
    const { id } = req.params;
    if (!id) return res.status(400).json({ message: "Competition ID required" });

    const competition = await Competition.findByIdAndDelete(id);
    
    if (!competition) {
      return res.status(404).json({ message: "Competition not found" });
    }

    res.json({ message: "Competition deleted", competition });
  } catch (err) {
    console.error("Error deleting competition:", err);
    res.status(500).json({ message: "Failed to delete competition", error: err.message });
  }
};


// ➤ View Analytics (Registration Count)
exports.analytics = async (req, res) => {
  try {
    const competitions = await Competition.find().sort({ registrationCount: -1 });
    res.json(competitions);
  } catch (err) {
    console.error("Error fetching analytics:", err);
    res.status(500).json({ message: "Failed to fetch analytics", error: err.message });
  }
};


// ➤ Confirm Registration
exports.confirmRegistration = async (req, res) => {
  try {
    const registration = await Registration.findByIdAndUpdate(
      req.params.id,
      { status: "approved" },
      { new: true }
    );
    if (!registration) {
      return res.status(404).json({ message: "Registration not found" });
    }
    res.json(registration);
  } catch (err) {
    console.error("Error confirming registration:", err);
    res.status(500).json({ message: "Failed to confirm registration", error: err.message });
  }
};


// ➤ Add Support Member
exports.addSupportMember = async (req, res) => {
  try {
    const { userId } = req.body;
    if (!userId) {
      return res.status(400).json({ message: "User ID required" });
    }

    const user = await User.findByIdAndUpdate(
      userId,
      { role: "support" },
      { new: true }
    );

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    res.json(user);
  } catch (err) {
    console.error("Error adding support member:", err);
    res.status(500).json({ message: "Failed to add support member", error: err.message });
  }
};

exports.addCategory = async (req, res) => {
  try {
    const { name } = req.body;
    if (!name) {
      return res.status(400).json({ message: "Category name required" });
    }

    const category = await Category.create({ name });
    res.status(201).json(category);
  } catch (err) {
    console.error("Error adding category:", err);
    res.status(500).json({ message: "Failed to add category", error: err.message });
  }
};

exports.getCategories = async (req, res) => {
  try {
    const categories = await Category.find();
    res.json(categories);
  } catch (err) {
    console.error("Error fetching categories:", err);
    res.status(500).json({ message: "Failed to fetch categories", error: err.message });
  }
};

exports.getAllRegistrations = async (req, res) => {
  try {
    const registrations = await Registration.find()
      .populate({ path: "user", select: "name email" })
      .populate({ 
        path: "competition", 
        select: "title category deadline",
        populate: { path: "category", select: "name" } // populate category if used
      });

    res.json(registrations);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server error" });
  }
};

// Approve or reject a registration
exports.updateRegistrationStatus = async (req, res) => {
  try {
    const { registrationId } = req.params;
    const { status } = req.body; // "approved" or "rejected"

    const registration = await Registration.findById(registrationId);
    if (!registration) return res.status(404).json({ message: "Registration not found" });

    registration.status = status;
    await registration.save();

    res.json({ message: `Registration ${status} successfully` });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server error" });
  }
};