const Competition = require("../models/Competition");

exports.getCompetitions = async (req, res) => {
  try {
    const { sort, category, search, date } = req.query;

    let query = {};

    // Search by title or description (highest priority)
    if (search && search.trim()) {
      query.$or = [
        { title: { $regex: search.trim(), $options: "i" } },
        { description: { $regex: search.trim(), $options: "i" } }
      ];
    }

    // Category filter
    if (category && category.trim()) {
      query.category = category.trim();
    }

    // Date filter
    if (date === "upcoming") {
      query.deadline = { $gte: new Date() };
    } else if (date === "past") {
      query.deadline = { $lt: new Date() };
    }

    console.log("Search Query:", query); // Debug log

    let competitions = Competition.find(query);

    // Sorting
    if (sort === "trending") {
      competitions = competitions.sort({ registrationCount: -1 });
    } else if (sort === "new") {
      competitions = competitions.sort({ createdAt: -1 });
    } else {
      // Default sort by newest
      competitions = competitions.sort({ createdAt: -1 });
    }

    const result = await competitions;
    console.log("Found competitions:", result.length); // Debug log
    res.json(result);
  } catch (err) {
    console.error("Error fetching competitions:", err);
    res.status(500).json({ message: "Failed to fetch competitions", error: err.message });
  }
};

exports.getCompetitionById = async (req, res) => {
  const comp = await Competition.findById(req.params.id);
  res.json(comp);
};
exports.calendarView = async (req, res) => {
  const competitions = await Competition.find().select("title deadline");

  const calendarData = competitions.map(comp => ({
    title: comp.title,
    date: comp.deadline
  }));

  res.json(calendarData);
};

