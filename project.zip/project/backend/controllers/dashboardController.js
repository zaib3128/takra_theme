const Registration = require("../models/Registration");

exports.getUserDashboard = async (req, res) => {
  try {
    const userId = req.user.id; // JWT middleware sets req.user

    // Find all registrations for this user and populate competition info
    const registrations = await Registration.find({ user: userId })
      .populate({
        path: "competition",
        select: "title description category deadline prizes",
        populate: { path: "category", select: "name" } // if category exists
      });

    res.json(registrations);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server error" });
  }
};
