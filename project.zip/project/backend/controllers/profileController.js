const User = require("../models/User");
const Registration = require("../models/Registration");
const bcrypt = require("bcryptjs");

// Get user profile
exports.getProfile = async (req, res) => {
  try {
    const user = await User.findById(req.user.id).select("-password");
    res.json(user);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server error" });
  }
};

// Get user's competitions they're participating in
exports.getMyCompetitions = async (req, res) => {
  try {
    const registrations = await Registration.find({ user: req.user.id })
      .populate("competition")
      .sort({ createdAt: -1 });

    res.json(registrations);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Failed to fetch competitions", error: error.message });
  }
};

// Update profile (name or password)
exports.updateProfile = async (req, res) => {
  try {
    const user = await User.findById(req.user.id);

    if (!user) return res.status(404).json({ message: "User not found" });

    const { name, password } = req.body;

    if (name) user.name = name;

    if (password) {
      const salt = await bcrypt.genSalt(10);
      user.password = await bcrypt.hash(password, salt);
    }

    await user.save();

    res.json({ message: "Profile updated successfully", user });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server error" });
  }
};
