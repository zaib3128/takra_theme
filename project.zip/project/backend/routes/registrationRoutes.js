const express = require("express");
const router = express.Router();
const Registration = require("../models/Registration");
const Competition = require("../models/Competition");
const verifyToken = require("../middleware/authMiddleware");

// Get user's registrations
router.get("/me", verifyToken, async (req, res) => {
  try {
    const registrations = await Registration.find({ user: req.user.id })
      .populate("competition")
      .sort({ createdAt: -1 });
    
    res.json(registrations);
  } catch (err) {
    res.status(500).json({ message: "Error fetching registrations", error: err.message });
  }
});

// Create registration
router.post("/:competitionId", verifyToken, async (req, res) => {
  try {
    const { competitionId } = req.params;
    const userId = req.user.id;

    // Check if user is already registered in this competition
    const existingRegistration = await Registration.findOne({
      user: userId,
      competition: competitionId
    });

    if (existingRegistration) {
      return res.status(400).json({ 
        message: "You are already enrolled in this competition" 
      });
    }

    // Create new registration
    const registration = await Registration.create({
      user: userId,
      competition: competitionId
    });

    // Increment registration count
    await Competition.findByIdAndUpdate(
      competitionId,
      { $inc: { registrationCount: 1 } }
    );

    res.status(201).json(registration);
  } catch (err) {
    console.error("Registration error:", err);
    res.status(500).json({ 
      message: "Failed to register for competition", 
      error: err.message 
    });
  }
});

// Delete registration
router.delete("/:registrationId", verifyToken, async (req, res) => {
  try {
    const { registrationId } = req.params;
    const userId = req.user.id;

    // Find the registration
    const registration = await Registration.findById(registrationId);
    
    if (!registration) {
      return res.status(404).json({ message: "Registration not found" });
    }

    // Check if the registration belongs to the current user
    if (registration.user.toString() !== userId) {
      return res.status(403).json({ message: "You can only delete your own registrations" });
    }

    // Delete the registration
    await Registration.findByIdAndDelete(registrationId);

    // Decrement registration count
    await Competition.findByIdAndUpdate(
      registration.competition,
      { $inc: { registrationCount: -1 } }
    );

    res.json({ message: "Registration deleted successfully" });
  } catch (err) {
    console.error("Delete registration error:", err);
    res.status(500).json({ 
      message: "Failed to delete registration", 
      error: err.message 
    });
  }
});

module.exports = router;
