const express = require("express");
const router = express.Router();
const { getCompetitions, getCompetitionById } = require("../controllers/competitionController");
const { calendarView } = require("../controllers/competitionController");


router.get("/", getCompetitions);
router.get("/:id", getCompetitionById);
router.get("/calendar/view", calendarView);



module.exports = router;
