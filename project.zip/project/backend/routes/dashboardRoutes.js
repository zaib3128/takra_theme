const express = require("express");
const router = express.Router();

const { getUserDashboard } = require("../controllers/dashboardController");
const verifyToken = require("../middleware/authMiddleware"); // JWT middleware

// GET /api/dashboard → view registered competitions
router.get("/", verifyToken, getUserDashboard);

module.exports = router;
