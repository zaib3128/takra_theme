const express = require("express");
const router = express.Router();

const { getProfile, updateProfile, getMyCompetitions } = require("../controllers/profileController");
const verifyToken = require("../middleware/authMiddleware");

// Get profile
router.get("/", verifyToken, getProfile);

// Get user's competitions they're participating in
router.get("/competitions/me", verifyToken, getMyCompetitions);

// Update profile
router.put("/", verifyToken, updateProfile);

module.exports = router;
