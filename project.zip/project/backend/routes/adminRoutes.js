const express = require("express");
const router = express.Router();

const verifyToken = require("../middleware/authMiddleware");
const checkRole = require("../middleware/roleMiddleware");
const { addCategory, getCategories } = require("../controllers/adminController");

const {
  addCompetition,
  updateCompetition,
  deleteCompetition,
  analytics,
  confirmRegistration,
  addSupportMember,
  getAllRegistrations,
  updateRegistrationStatus,
} = require("../controllers/adminController");


// Protect all admin routes
router.use(verifyToken, checkRole("admin"));
router.post("/competition",verifyToken,checkRole("admin"), addCompetition);
router.put("/competition/:id", verifyToken,checkRole("admin"),updateCompetition);
router.delete("/competition/:id", verifyToken,checkRole("admin"),deleteCompetition);
router.get("/analytics",verifyToken,checkRole("admin"), analytics);
router.put("/confirm/:id",verifyToken, checkRole("admin"),confirmRegistration);
router.put("/support",verifyToken, checkRole("admin"), addSupportMember);
router.post("/category",verifyToken, checkRole("admin"), addCategory);
router.get("/categories",verifyToken, getCategories);
router.get("/registrations", verifyToken, checkRole("admin"), getAllRegistrations);
// Approve/Reject a registration
router.put("/registrations/:registrationId", verifyToken, checkRole("admin"), updateRegistrationStatus);

module.exports = router;
