require("dotenv").config();
const express = require("express");
const cors = require("cors");
const http = require("http");
const { Server } = require("socket.io");

const connectDB = require("./config/db");

// Initialize app and server
const app = express();
const server = http.createServer(app);

// Setup Socket.io with CORS configuration
const io = new Server(server, { 
  cors: { 
    origin: process.env.FRONTEND_URL || ["http://localhost:5173", "http://localhost:3000"],
    methods: ["GET", "POST"],
    credentials: true
  }
});

// Connect Database
connectDB();

// Middleware
app.use(cors({
  origin: process.env.FRONTEND_URL || ["http://localhost:5173", "http://localhost:3000"],
  credentials: true
}));
app.use(express.json());

// Store io instance to be used in routes if needed
app.set('io', io);

// Health check endpoint
app.get("/api/health", (req, res) => {
  res.json({ status: "OK", message: "Backend is running" });
});

// ----------------- ROUTES -----------------
app.use("/api/auth", require("./routes/authRoutes"));
app.use("/api/admin", require("./routes/adminRoutes"));
app.use("/api/chatbot", require("./routes/chatbotRoutes"));
app.use("/api/competitions", require("./routes/competitionRoutes"));
app.use("/api/register", require("./routes/registrationRoutes"));
app.use("/api/dashboard", require("./routes/dashboardRoutes"));
app.use("/api/profile", require("./routes/profileRoutes"));



// ----------------- SOCKET.IO -----------------
io.on("connection", (socket) => {
  console.log("User connected:", socket.id);

  // 1️⃣ Join room based on role
  socket.on("joinRoom", ({ userId, role }) => {
    if (role === "admin" || role === "support") {
      socket.join("supportRoom");
      console.log(`Admin/Support joined supportRoom`);
    } else {
      socket.join(userId); // personal room
      console.log(`User joined room: ${userId}`);
    }
  });

  // 2️⃣ User sends message to support
  socket.on("userMessage", ({ userId, message }) => {
    io.to("supportRoom").emit("receiveMessage", {
      from: userId,
      message
    });
    console.log(`Message from user ${userId}: ${message}`);
  });

  // 3️⃣ Admin/support replies
  socket.on("supportReply", ({ userId, message }) => {
    io.to(userId).emit("receiveMessage", {
      from: "support",
      message
    });
    console.log(`Support replied to ${userId}: ${message}`);
  });

  // 4️⃣ Your old generic message listener
  socket.on("message", (data) => {
    io.emit("message", data);
    console.log("Generic message:", data);
  });

  // Disconnect
  socket.on("disconnect", () => {
    console.log("User disconnected:", socket.id);
  });
});

// ----------------- START SERVER -----------------
const PORT = process.env.PORT || 5000;
server.listen(PORT, () => console.log(`Server running on port ${PORT}`));
