# TAAKRA - Competition Management Platform

## 📋 Project Overview

TAAKRA is a full-stack competition management platform that enables users to discover, register, and participate in competitions. Admins can manage competitions, approve registrations, and oversee the platform. The application features real-time updates, user authentication, role-based access control, and advanced search functionality.

---

## 🛠 Tech Stack

### Frontend
- **Framework**: React 19 with Vite 7
- **Styling**: Tailwind CSS 4
- **Routing**: React Router 6
- **HTTP Client**: Axios with JWT interceptors
- **Real-time**: Socket.io-client
- **Calendar**: React Calendar
- **State Management**: React Context API

### Backend
- **Runtime**: Node.js
- **Framework**: Express 5
- **Database**: MongoDB with Mongoose
- **Authentication**: JWT (JSON Web Tokens)
- **Encryption**: bcryptjs for password hashing
- **Real-time**: Socket.io
- **API Style**: RESTful

---

## ✨ Key Features

### User Features
- ✅ **User Authentication** - Secure login/register with JWT tokens
- ✅ **Competition Browsing** - View all competitions with detailed information
- ✅ **Advanced Search** - Search by title/keyword with real-time filtering
- ✅ **Filtering** - Filter by category (Design, Tech, Business)
- ✅ **Date Filtering** - Show upcoming or past deadline competitions
- ✅ **Sorting** - Sort by trending (most enrolled) or newest
- ✅ **Competition Registration** - Enroll in competitions with duplicate prevention
- ✅ **Dashboard** - View registered competitions with enrollment status
- ✅ **Profile Management** - View and edit user profile
- ✅ **Withdrawal** - Withdraw from competitions anytime
- ✅ **Real-time Sync** - Auto-refresh when switching browser tabs
- ✅ **Calendar View** - View competitions on a calendar by deadline

### Admin Features
- ✅ **Admin Dashboard** - Complete control panel for admins only
- ✅ **Competition Management** - Create, edit, update, delete competitions
- ✅ **Registration Management** - View all user registrations
- ✅ **Approval System** - Approve or reject user registrations
- ✅ **Analytics** - Track competition statistics and enrollment counts
- ✅ **Admin Restrictions** - Admins cannot participate in competitions

---

## 📁 Project Structure

```
project/
├── frontend/
│   ├── src/
│   │   ├── pages/
│   │   │   ├── Home.jsx              # Browse competitions
│   │   │   ├── Login.jsx             # User login
│   │   │   ├── Register.jsx          # User registration
│   │   │   ├── Dashboard.jsx         # User dashboard
│   │   │   ├── AdminDashboard.jsx    # Admin control panel
│   │   │   ├── Profile.jsx           # User profile
│   │   │   ├── CompetitionDetail.jsx # Competition details
│   │   │   └── CalendarView.jsx      # Calendar view
│   │   ├── components/
│   │   │   ├── Navbar.jsx            # Navigation bar
│   │   │   ├── CompetitionCard.jsx   # Competition card
│   │   │   ├── Chatbot.jsx           # AI chatbot
│   │   │   └── ChatBox.jsx           # Chat interface
│   │   ├── context/
│   │   │   └── AuthContext.jsx       # Authentication context
│   │   ├── api/
│   │   │   └── axios.js              # API client with interceptors
│   │   ├── App.jsx                   # Main app component
│   │   ├── main.jsx                  # Entry point
│   │   └── index.css                 # Global styles
│   ├── public/
│   │   └── logo.png                  # Application logo
│   ├── .env                          # Environment variables
│   ├── package.json
│   ├── vite.config.js
│   └── README.md
├── backend/
│   ├── routes/
│   │   ├── authRoutes.js             # Authentication endpoints
│   │   ├── competitionRoutes.js      # Competition endpoints
│   │   ├── registrationRoutes.js     # Registration endpoints
│   │   ├── adminRoutes.js            # Admin endpoints
│   │   ├── profileRoutes.js          # Profile endpoints
│   │   ├── dashboardRoutes.js        # Dashboard endpoints
│   │   ├── chatbotRoutes.js          # Chatbot endpoints
│   │   └── chatRoutes.js             # Chat endpoints
│   ├── controllers/
│   │   ├── authController.js         # Auth logic
│   │   ├── competitionController.js  # Competition logic
│   │   ├── adminController.js        # Admin logic
│   │   ├── registrationController.js # Registration logic
│   │   └── profileController.js      # Profile logic
│   ├── models/
│   │   ├── User.js                   # User schema
│   │   ├── Competition.js            # Competition schema
│   │   ├── Registration.js           # Registration schema
│   │   └── Category.js               # Category schema
│   ├── middleware/
│   │   ├── authMiddleware.js         # JWT verification
│   │   └── roleMiddleware.js         # Role-based access
│   ├── config/
│   │   └── db.js                     # MongoDB connection
│   ├── socket/
│   │   └── socket.js                 # Socket.io setup
│   ├── .env                          # Environment variables
│   ├── server.js                     # Main server file
│   ├── package.json
│   └── README.md
└── README.md (this file)
```

---

## 🚀 Getting Started

### Prerequisites
- Node.js (v14 or higher)
- npm or yarn
- MongoDB (local or Atlas connection string)

### Installation

#### 1. Clone or Extract Project
```bash
cd project
```

#### 2. Frontend Setup
```bash
cd frontend
npm install
```

Create `.env` file:
```env
VITE_API_URL=http://localhost:5000/api
VITE_SOCKET_URL=http://localhost:5000
```

#### 3. Backend Setup
```bash
cd ../backend
npm install
```

Create `.env` file:
```env
MONGO_URI=mongodb://localhost:27017/taakra
JWT_SECRET=your_jwt_secret_key_here
PORT=5000
```

---

## 🏃 Running the Application

### Terminal 1: Start Backend
```bash
cd backend
npm start
```
Backend runs on: `http://localhost:5000`

### Terminal 2: Start Frontend
```bash
cd frontend
npm run dev
```
Frontend runs on: `http://localhost:5173`

### Access Application
Open browser and go to: `http://localhost:5173`

---

## 🔑 Default Test Accounts

### User Account
- **Email**: user@gmail.com
- **Password**: password123

### Admin Account
- **Email**: admin@gmail.com
- **Password**: password123

---

## 📡 API Endpoints

### Authentication
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/register` | Register new user |
| POST | `/api/auth/login` | User login |

### Competitions
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/competitions` | Get all competitions (with filters) |
| GET | `/api/competitions/:id` | Get competition by ID |
| GET | `/api/competitions/calendar/view` | Get calendar view |

**Query Parameters for Search:**
- `search` - Search by title/keyword
- `category` - Filter by category (design, tech, business)
- `date` - Filter by date (upcoming, past)
- `sort` - Sort by (trending, new)

### Registrations
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/register/:competitionId` | Register for competition |
| DELETE | `/api/register/:registrationId` | Withdraw from competition |
| GET | `/api/profile/competitions/me` | Get my registrations |

### Admin
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/admin/competition` | Create competition |
| PUT | `/api/admin/competition/:id` | Update competition |
| DELETE | `/api/admin/competition/:id` | Delete competition |
| GET | `/api/admin/registrations` | Get all registrations |
| PUT | `/api/admin/registrations/:id` | Approve/reject registration |

### Profile
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/profile` | Get user profile |
| PUT | `/api/profile` | Update user profile |

---

## 👥 User Roles

### User
- Browse competitions
- Search and filter competitions
- Register for competitions
- View dashboard with registrations
- Withdraw from competitions
- Manage profile
- Cannot access admin features

### Admin
- Full control over competitions (CRUD)
- View all registrations
- Approve/reject registrations
- Cannot participate in competitions
- Access admin dashboard only

---

## 🔍 Search & Filter Features

### Real-time Search
- Type in search bar to filter by competition title or keyword
- 500ms debounce to optimize API calls
- Case-insensitive matching

### Category Filter
- Design
- Tech
- Business
- All Categories (default)

### Date Filter
- Upcoming Deadlines - Shows competitions ending after today
- Past Deadlines - Shows competitions that have passed
- All Dates (default)

### Sorting Options
- Trending 🔥 - Sorted by most enrollments
- Newest 🆕 - Sorted by creation date

---

## 🎨 UI Features

### Logo Display
- Application logo appears behind every page as watermark
- 70% opacity for visibility without obstruction
- Consistent branding across all pages

### Responsive Design
- Mobile-friendly layout
- Tailwind CSS responsive classes
- Works on all screen sizes

### Real-time Updates
- Auto-refresh when switching browser tabs
- Optimistic UI updates
- Real-time data synchronization

---

## 🔐 Security Features

- ✅ **JWT Authentication** - Secure token-based authentication
- ✅ **Password Hashing** - bcryptjs encryption
- ✅ **Role-Based Access Control** - Admin/User distinctions
- ✅ **Token Expiration** - 1-day token validity
- ✅ **CORS Configuration** - Restricted cross-origin requests
- ✅ **Input Validation** - Server-side validation

---

## 🐛 Troubleshooting

### Backend won't start
```bash
# Check if port 5000 is in use
# Try different port in .env
# Verify MongoDB connection string
```

### Frontend won't connect to backend
```bash
# Check VITE_API_URL in .env matches backend URL
# Verify backend is running on correct port
# Clear browser cache and reload
```

### Search not working
```bash
# Verify query parameters are correct
# Check backend console for errors
# Ensure MongoDB is accessible
```

### Logo not showing
```bash
# Clear browser cache (Ctrl+Shift+Delete)
# Check logo.png exists in /public folder
# Verify CSS z-index settings
```

---

## 📝 Environment Variables

### Frontend (.env)
```env
VITE_API_URL=http://localhost:5000/api
VITE_SOCKET_URL=http://localhost:5000
```

### Backend (.env)
```env
MONGO_URI=mongodb://localhost:27017/taakra
JWT_SECRET=your_secret_key
PORT=5000
FRONTEND_URL=http://localhost:5173
```

---

## 🚀 Deployment

### Frontend Deployment (Vercel/Netlify)
```bash
cd frontend
npm run build
# Deploy the dist/ folder
```

### Backend Deployment (Heroku/Railway)
```bash
cd backend
# Connect to MongoDB Atlas
# Update environment variables
# Deploy using git or CLI
```

---

## 📚 Additional Features

### Socket.io Real-time Chat
- Live messaging between users and support
- Admin support room
- Real-time notifications

### AI Chatbot
- OpenAI integration (dummy mode)
- Intelligent responses
- Help and support

### Calendar View
- Visual competition calendar
- Filter by deadline dates
- Easy deadline tracking

---

## 🤝 Contributing

To contribute to this project:
1. Create a feature branch
2. Make your changes
3. Test thoroughly
4. Submit a pull request

---

## 📄 License

This project is proprietary and confidential.

---

## 📧 Support

For issues or questions, contact:
- Email: support@taakra.com
- Documentation: See individual component files

---

## ✅ Checklist - Features Completed

- [x] User authentication (register/login)
- [x] Competition browsing
- [x] Advanced search with filters
- [x] Real-time filtering
- [x] User dashboard
- [x] Admin dashboard
- [x] Competition management (CRUD)
- [x] Registration system
- [x] Duplicate enrollment prevention
- [x] Registration approval system
- [x] Profile management
- [x] Withdrawal functionality
- [x] Real-time data sync
- [x] Calendar view
- [x] Logo display on all pages
- [x] Role-based access control
- [x] Admin-only dashboard access
- [x] Socket.io integration
- [x] Responsive design
- [x] Error handling

---

**Last Updated**: February 14, 2026
**Version**: 1.0.0
