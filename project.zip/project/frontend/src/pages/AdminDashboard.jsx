import React, { useState, useEffect, useContext } from "react";
import api from "../api/axios";
import { AuthContext } from "../context/AuthContext";
import { Navigate } from "react-router-dom";

export default function AdminDashboard() {
  const { user } = useContext(AuthContext);
  const [competitions, setCompetitions] = useState([]);
  const [registrations, setRegistrations] = useState([]);
  const [activeTab, setActiveTab] = useState("competitions");
  const [formData, setFormData] = useState({ title: "", description: "", category: "design", deadline: "", prizes: "" });
  const [message, setMessage] = useState("");
  const [isEditing, setIsEditing] = useState(false);
  const [editingId, setEditingId] = useState(null);

  useEffect(() => {
    if (user && user.role === "admin") {
      fetchCompetitions();
      fetchRegistrations();
    }
  }, [user]);

  const fetchCompetitions = async () => {
    try {
      const res = await api.get("/competitions");
      setCompetitions(Array.isArray(res.data) ? res.data : []);
    } catch (err) {
      console.error("Failed to fetch competitions", err);
    }
  };

  const fetchRegistrations = async () => {
    try {
      const res = await api.get("/admin/registrations");
      setRegistrations(Array.isArray(res.data) ? res.data : []);
    } catch (err) {
      console.error("Failed to fetch registrations", err);
    }
  };

  const handleCreate = async (e) => {
    e.preventDefault();
    try {
      if (isEditing) {
        // Update existing competition
        await api.put(`/admin/competition/${editingId}`, formData);
        setMessage("Competition updated successfully!");
        setIsEditing(false);
        setEditingId(null);
      } else {
        // Create new competition
        await api.post("/admin/competition", formData);
        setMessage("Competition created successfully!");
      }
      fetchCompetitions();
      setFormData({ title: "", description: "", category: "design", deadline: "", prizes: "" });
      setTimeout(() => setMessage(""), 3000);
    } catch (err) {
      setMessage("Failed to " + (isEditing ? "update" : "create") + " competition.");
    }
  };

  const handleEdit = (competition) => {
    setFormData({
      title: competition.title,
      description: competition.description,
      category: competition.category,
      deadline: competition.deadline ? competition.deadline.split("T")[0] : "",
      prizes: competition.prizes
    });
    setEditingId(competition._id);
    setIsEditing(true);
  };

  const handleCancel = () => {
    setIsEditing(false);
    setEditingId(null);
    setFormData({ title: "", description: "", category: "design", deadline: "", prizes: "" });
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this?")) return;
    try {
      await api.delete(`/admin/competition/${id}`);
      fetchCompetitions();
    } catch (err) {
      alert("Failed to delete.");
    }
  };

  const handleApproveRegistration = async (registrationId) => {
    try {
      await api.put(`/admin/registrations/${registrationId}`, { status: "approved" });
      setMessage("Registration approved!");
      fetchRegistrations();
      setTimeout(() => setMessage(""), 3000);
    } catch (err) {
      alert("Failed to approve registration: " + (err.response?.data?.message || err.message));
    }
  };

  const handleRejectRegistration = async (registrationId) => {
    try {
      await api.put(`/admin/registrations/${registrationId}`, { status: "rejected" });
      setMessage("Registration rejected!");
      fetchRegistrations();
      setTimeout(() => setMessage(""), 3000);
    } catch (err) {
      alert("Failed to reject registration: " + (err.response?.data?.message || err.message));
    }
  };

  if (!user || user.role !== "admin") return <Navigate to="/" />;

  return (
    <div className="min-h-screen bg-transparent p-6">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-4xl font-bold text-gray-900 mb-8">Admin Control Panel</h1>

        {/* Tab Navigation */}
        <div className="flex gap-4 mb-8 border-b border-gray-200">
          <button
            onClick={() => setActiveTab("competitions")}
            className={`px-6 py-3 font-semibold transition ${
              activeTab === "competitions"
                ? "border-b-2 border-blue-600 text-blue-600"
                : "text-gray-600 hover:text-gray-900"
            }`}
          >
            Manage Competitions
          </button>
          <button
            onClick={() => setActiveTab("registrations")}
            className={`px-6 py-3 font-semibold transition ${
              activeTab === "registrations"
                ? "border-b-2 border-blue-600 text-blue-600"
                : "text-gray-600 hover:text-gray-900"
            }`}
          >
            Approve Registrations
          </button>
        </div>

        {message && (
          <div className={`mb-6 p-4 rounded font-semibold ${
            message.includes("successfully") || message.includes("approved") || message.includes("rejected")
              ? "bg-green-100 text-green-800"
              : "bg-red-100 text-red-800"
          }`}>
            {message}
          </div>
        )}

        {/* Competitions Tab */}
        {activeTab === "competitions" && (
          <>
            {/* Create/Edit Competition Form */}
            <div className="bg-white p-6 rounded-lg shadow-md mb-8 border border-gray-200">
              <h2 className="text-2xl font-bold mb-6">
                {isEditing ? "Edit Competition" : "Create New Competition"}
              </h2>
              <form onSubmit={handleCreate} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <input
                  type="text"
                  placeholder="Title"
                  required
                  className="border p-3 rounded focus:outline-none focus:ring-2 focus:ring-blue-400"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                />
                <select
                  className="border p-3 rounded focus:outline-none focus:ring-2 focus:ring-blue-400"
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                >
                  <option value="design">Design</option>
                  <option value="tech">Tech</option>
                  <option value="business">Business</option>
                </select>
                <input
                  type="date"
                  required
                  className="border p-3 rounded focus:outline-none focus:ring-2 focus:ring-blue-400"
                  value={formData.deadline}
                  onChange={(e) => setFormData({ ...formData, deadline: e.target.value })}
                />
                <input
                  type="text"
                  placeholder="Prizes (e.g., $500, Swag)"
                  required
                  className="border p-3 rounded focus:outline-none focus:ring-2 focus:ring-blue-400"
                  value={formData.prizes}
                  onChange={(e) => setFormData({ ...formData, prizes: e.target.value })}
                />
                <textarea
                  placeholder="Description"
                  required
                  className="border p-3 rounded focus:outline-none focus:ring-2 focus:ring-blue-400 md:col-span-2"
                  rows="3"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                ></textarea>
                <div className="md:col-span-2 flex gap-3">
                  <button
                    type="submit"
                    className="flex-1 bg-blue-600 text-white font-bold p-3 rounded hover:bg-blue-700 transition"
                  >
                    {isEditing ? "Update Competition" : "Add Competition"}
                  </button>
                  {isEditing && (
                    <button
                      type="button"
                      onClick={handleCancel}
                      className="flex-1 bg-gray-600 text-white font-bold p-3 rounded hover:bg-gray-700 transition"
                    >
                      Cancel
                    </button>
                  )}
                </div>
              </form>
            </div>

            {/* List of Competitions */}
            <div className="bg-white rounded-lg shadow-md border border-gray-200 overflow-hidden">
              <h2 className="text-2xl font-bold p-6 bg-gray-50 border-b">All Competitions</h2>
              <div className="p-6 grid gap-4">
                {competitions.length === 0 ? (
                  <p className="text-gray-500 text-center py-8">No competitions yet</p>
                ) : (
                  competitions.map((comp) => (
                    <div key={comp._id} className="flex justify-between items-center p-4 border rounded hover:bg-gray-50 transition">
                      <div>
                        <h3 className="font-bold text-lg text-gray-900">{comp.title}</h3>
                        <p className="text-sm text-gray-600">
                          Category: <span className="capitalize">{comp.category}</span> | Enrolled: {comp.registrationCount} | Ends: {new Date(comp.deadline).toLocaleDateString()}
                        </p>
                      </div>
                      <div className="flex gap-3">
                        <button
                          onClick={() => handleEdit(comp)}
                          className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded transition"
                        >
                          Edit
                        </button>
                        <button
                          onClick={() => handleDelete(comp._id)}
                          className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded transition"
                        >
                          Delete
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </>
        )}

        {/* Registrations Tab */}
        {activeTab === "registrations" && (
          <div className="bg-white rounded-lg shadow-md border border-gray-200 overflow-hidden">
            <h2 className="text-2xl font-bold p-6 bg-gray-50 border-b">User Registrations</h2>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-100 border-b">
                  <tr>
                    <th className="px-6 py-3 text-left font-semibold text-gray-800">User Name</th>
                    <th className="px-6 py-3 text-left font-semibold text-gray-800">Email</th>
                    <th className="px-6 py-3 text-left font-semibold text-gray-800">Competition</th>
                    <th className="px-6 py-3 text-left font-semibold text-gray-800">Status</th>
                    <th className="px-6 py-3 text-left font-semibold text-gray-800">Registered Date</th>
                    <th className="px-6 py-3 text-center font-semibold text-gray-800">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {registrations.length === 0 ? (
                    <tr>
                      <td colSpan="6" className="px-6 py-8 text-center text-gray-500">
                        No registrations yet
                      </td>
                    </tr>
                  ) : (
                    registrations.map((reg) => (
                      <tr key={reg._id} className="border-b hover:bg-gray-50 transition">
                        <td className="px-6 py-4 text-gray-900 font-medium">{reg.user?.name || "Unknown"}</td>
                        <td className="px-6 py-4 text-gray-700">{reg.user?.email || "N/A"}</td>
                        <td className="px-6 py-4 text-gray-700">{reg.competition?.title || "Unknown"}</td>
                        <td className="px-6 py-4">
                          <span
                            className={`px-3 py-1 rounded-full text-xs font-bold uppercase ${
                              reg.status === "approved"
                                ? "bg-green-100 text-green-800"
                                : reg.status === "rejected"
                                ? "bg-red-100 text-red-800"
                                : "bg-yellow-100 text-yellow-800"
                            }`}
                          >
                            {reg.status}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-gray-600 text-sm">
                          {new Date(reg.createdAt).toLocaleDateString()}
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex gap-2 justify-center">
                            {reg.status !== "approved" && (
                              <button
                                onClick={() => handleApproveRegistration(reg._id)}
                                className="bg-green-600 hover:bg-green-700 text-white px-3 py-1 rounded text-sm transition"
                              >
                                ✓ Approve
                              </button>
                            )}
                            {reg.status !== "rejected" && (
                              <button
                                onClick={() => handleRejectRegistration(reg._id)}
                                className="bg-red-600 hover:bg-red-700 text-white px-3 py-1 rounded text-sm transition"
                              >
                                ✗ Reject
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}