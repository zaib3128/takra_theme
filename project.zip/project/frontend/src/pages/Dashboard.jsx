import React, { useState, useEffect, useContext } from "react";
import api from "../api/axios";
import { AuthContext } from "../context/AuthContext";
import { Navigate } from "react-router-dom";

export default function Dashboard() {
  const { user } = useContext(AuthContext);
  const [registrations, setRegistrations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    if (user && user.role !== "admin") {
      fetchMyRegistrations();
    }
  }, [user]);

  // Auto-refresh when page becomes visible
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (!document.hidden && user && user.role !== "admin") {
        fetchMyRegistrations();
      }
    };

    document.addEventListener("visibilitychange", handleVisibilityChange);
    return () => document.removeEventListener("visibilitychange", handleVisibilityChange);
  }, [user]);

  const fetchMyRegistrations = async () => {
    try {
      if (!refreshing) setLoading(true);
      const res = await api.get("/profile/competitions/me"); 
      setRegistrations(Array.isArray(res.data) ? res.data : []);
    } catch (err) {
      console.error("Failed to fetch registrations", err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const handleRefresh = () => {
    setRefreshing(true);
    fetchMyRegistrations();
  };

  const handleDelete = async (registrationId) => {
    if (!window.confirm("Are you sure you want to withdraw from this competition?")) {
      return;
    }

    try {
      setRefreshing(true);
      await api.delete(`/register/${registrationId}`);
      // Remove the registration from the UI immediately
      setRegistrations(registrations.filter(reg => reg._id !== registrationId));
      setRefreshing(false);
    } catch (err) {
      setRefreshing(false);
      alert("Failed to withdraw from competition: " + (err.response?.data?.message || err.message));
    }
  };

  // Protect route
  if (!user) return <Navigate to="/login" />;
  if (user.role === "admin") return <Navigate to="/admin" />;

  if (loading) return <div className="min-h-screen flex items-center justify-center">Loading...</div>;

  return (
    <div className="min-h-screen bg-transparent p-6">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8 flex justify-between items-center">
          <div>
            <h1 className="text-4xl font-bold text-gray-900">My Dashboard</h1>
            <p className="text-gray-600 mt-2">Welcome back, {user.name}! Here are your competitions.</p>
          </div>
          <button
            onClick={handleRefresh}
            disabled={refreshing}
            className={`px-4 py-2 rounded font-semibold transition ${
              refreshing
                ? "bg-gray-400 text-white cursor-wait"
                : "bg-blue-600 text-white hover:bg-blue-700 cursor-pointer"
            }`}
          >
            {refreshing ? "Refreshing..." : "🔄 Refresh"}
          </button>
        </div>
        
        {registrations.length === 0 ? (
          <div className="bg-white p-12 rounded-lg shadow text-center border-2 border-dashed border-gray-300">
            <p className="text-gray-500 text-lg mb-4">You haven't registered for any competitions yet.</p>
            <a href="/" className="text-blue-600 hover:underline font-semibold">
              Browse all competitions →
            </a>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {registrations.map((registration) => (
              <div
                key={registration._id}
                className="bg-white rounded-lg shadow-md hover:shadow-lg transition border-l-4 border-blue-500 overflow-hidden"
              >
                <div className="p-6">
                  <h3 className="text-lg font-bold text-gray-900 mb-3">
                    {registration.competition?.title || "Unknown Competition"}
                  </h3>

                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Category:</span>
                      <span className="capitalize font-semibold text-gray-800">
                        {registration.competition?.category || "N/A"}
                      </span>
                    </div>

                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Status:</span>
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-bold uppercase ${
                          registration.status === "approved"
                            ? "bg-green-100 text-green-800"
                            : registration.status === "rejected"
                            ? "bg-red-100 text-red-800"
                            : "bg-yellow-100 text-yellow-800"
                        }`}
                      >
                        {registration.status}
                      </span>
                    </div>

                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Deadline:</span>
                      <span className="font-semibold text-gray-800">
                        {registration.competition?.deadline
                          ? new Date(registration.competition.deadline).toLocaleDateString()
                          : "N/A"}
                      </span>
                    </div>

                    <div className="flex justify-between items-start">
                      <span className="text-gray-600">Prizes:</span>
                      <span className="font-semibold text-gray-800 text-right max-w-37.5">
                        {registration.competition?.prizes || "N/A"}
                      </span>
                    </div>

                    <div className="pt-2 border-t border-gray-200 mt-2">
                      <p className="text-xs text-gray-500">
                        Registered: {new Date(registration.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => handleDelete(registration._id)}
                    className="w-full mt-4 bg-red-600 hover:bg-red-700 text-white px-3 py-2 rounded font-semibold text-sm transition"
                  >
                    Withdraw
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}