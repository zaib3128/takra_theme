import React, { useState, useEffect, useContext } from "react";
import api from "../api/axios";
import { AuthContext } from "../context/AuthContext";
import { Navigate } from "react-router-dom";

export default function Profile() {
  const { user } = useContext(AuthContext);
  const [profile, setProfile] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({ name: "", password: "" });
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(true);

  // Fetch user profile on mount
  useEffect(() => {
    if (user) {
      fetchProfile();
    }
  }, [user]);

  const fetchProfile = async () => {
    try {
      const res = await api.get("/profile");
      setProfile(res.data);
      setFormData({ name: res.data.name, password: "" });
    } catch (err) {
      console.error("Failed to fetch profile", err);
      setMessage("Error loading profile");
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateProfile = async (e) => {
    e.preventDefault();
    try {
      const updateData = { name: formData.name };
      if (formData.password) {
        updateData.password = formData.password;
      }

      const res = await api.put("/profile", updateData);
      setMessage("Profile updated successfully!");
      setProfile(res.data.user);
      setIsEditing(false);
      setFormData({ ...formData, password: "" });
      setTimeout(() => setMessage(""), 3000);
    } catch (err) {
      setMessage("Failed to update profile");
    }
  };

  // Protect route
  if (!user) return <Navigate to="/login" />;
  if (loading) return <div className="min-h-screen flex items-center justify-center">Loading...</div>;

  return (
    <div className="min-h-screen bg-transparent p-6">
      <div className="max-w-2xl mx-auto">
        {/* Profile Section */}
        <div className="bg-white rounded-lg shadow-md p-8">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-3xl font-bold text-gray-900">My Profile</h1>
            <button
              onClick={() => setIsEditing(!isEditing)}
              className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded transition"
            >
              {isEditing ? "Cancel" : "Edit Profile"}
            </button>
          </div>

          {message && (
            <div className={`mb-4 p-3 rounded ${message.includes("successfully") ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}`}>
              {message}
            </div>
          )}

          {!isEditing ? (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-gray-600 mb-1">Name</label>
                <p className="text-lg text-gray-900 bg-gray-50 p-3 rounded">{profile?.name}</p>
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-600 mb-1">Email</label>
                <p className="text-lg text-gray-900 bg-gray-50 p-3 rounded">{profile?.email}</p>
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-600 mb-1">Role</label>
                <p className="text-lg text-gray-900 bg-gray-50 p-3 rounded capitalize">{profile?.role}</p>
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-600 mb-1">Member Since</label>
                <p className="text-lg text-gray-900 bg-gray-50 p-3 rounded">
                  {profile?.createdAt ? new Date(profile.createdAt).toLocaleDateString() : "N/A"}
                </p>
              </div>
            </div>
          ) : (
            <form onSubmit={handleUpdateProfile} className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-gray-600 mb-2">Name</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full border p-3 rounded focus:outline-none focus:ring-2 focus:ring-blue-400"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-600 mb-2">New Password (Optional)</label>
                <input
                  type="password"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  placeholder="Leave empty to keep current password"
                  className="w-full border p-3 rounded focus:outline-none focus:ring-2 focus:ring-blue-400"
                />
              </div>
              <button
                type="submit"
                className="w-full bg-blue-600 hover:bg-blue-700 text-white p-3 rounded transition font-bold"
              >
                Save Changes
              </button>
            </form>
          )}
        </div>

        {/* Link to Dashboard */}
        <div className="mt-8 text-center">
          <p className="text-gray-600 mb-2">Want to see your competitions?</p>
          <a href="/dashboard" className="text-blue-600 hover:underline font-semibold">
            Go to Dashboard →
          </a>
        </div>
      </div>
    </div>
  );
}
