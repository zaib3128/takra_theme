import React, { useState, useEffect, useContext } from "react";
import { useParams, useNavigate } from "react-router-dom";
import api from "../api/axios";
import { AuthContext } from "../context/AuthContext";

export default function CompetitionDetail() {
  const { id } = useParams();
  const { user } = useContext(AuthContext);
  const navigate = useNavigate();
  const [comp, setComp] = useState(null);
  const [message, setMessage] = useState("");
  const [isEnrolled, setIsEnrolled] = useState(false);
  const [loading, setLoading] = useState(true);
  const [registering, setRegistering] = useState(false);

  useEffect(() => {
    const fetchDetail = async () => {
      try {
        const res = await api.get(`/competitions/${id}`);
        setComp(res.data);
        
        // Check if user is already enrolled
        if (user) {
          checkEnrollmentStatus();
        }
      } catch (err) {
        console.error("Failed to load details", err);
      } finally {
        setLoading(false);
      }
    };
    fetchDetail();
  }, [id, user]);

  const checkEnrollmentStatus = async () => {
    try {
      const res = await api.get("/profile/competitions/me");
      const enrolledComps = Array.isArray(res.data) ? res.data : [];
      const isUserEnrolled = enrolledComps.some(reg => reg.competition?._id === id);
      setIsEnrolled(isUserEnrolled);
    } catch (err) {
      console.error("Failed to check enrollment status", err);
    }
  };

  const handleRegister = async () => {
    if (!user) {
      navigate("/login");
      return;
    }

    if (user.role === "admin") {
      setMessage("Admins cannot participate in competitions. Please use the admin dashboard to manage competitions.");
      return;
    }

    if (isEnrolled) {
      setMessage("You are already enrolled in this competition");
      return;
    }

    setRegistering(true);
    try {
      await api.post(`/register/${id}`);
      setMessage("Successfully registered!");
      setIsEnrolled(true);
      // Optimistic UI update
      setComp({ ...comp, registrationCount: comp.registrationCount + 1 });
      setTimeout(() => setMessage(""), 3000);
    } catch (err) {
      const errorMsg = err.response?.data?.message || "Registration failed";
      setMessage(errorMsg);
      if (errorMsg.includes("already enrolled")) {
        setIsEnrolled(true);
      }
    } finally {
      setRegistering(false);
    }
  };

  if (loading) return <div className="text-center p-20 text-xl text-gray-500">Loading competition...</div>;
  if (!comp) return <div className="text-center p-20 text-xl text-red-500">Competition not found</div>;

  return (
    <div className="container mx-auto p-6 max-w-3xl min-h-[80vh] bg-transparent">
      <div className="bg-white p-8 rounded-xl shadow-lg border border-gray-100">
        <h1 className="text-4xl font-extrabold text-gray-900 mb-4">{comp.title}</h1>
        <div className="flex gap-3 mb-6">
          <span className="bg-blue-100 text-blue-800 text-sm font-semibold px-3 py-1 rounded-full">
            {comp.category}
          </span>
          {isEnrolled && (
            <span className="bg-green-100 text-green-800 text-sm font-semibold px-3 py-1 rounded-full">
              ✓ Enrolled
            </span>
          )}
        </div>
        
        <p className="text-gray-700 text-lg leading-relaxed mb-8">{comp.description}</p>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-gray-50 p-6 rounded-lg mb-8">
          <div>
            <p className="text-xs text-gray-500 uppercase font-bold tracking-wider mb-1">Prizes</p>
            <p className="font-semibold text-gray-800">{comp.prizes}</p>
          </div>
          <div>
            <p className="text-xs text-gray-500 uppercase font-bold tracking-wider mb-1">Deadline</p>
            <p className="font-semibold text-gray-800">{new Date(comp.deadline).toLocaleDateString()}</p>
          </div>
          <div>
            <p className="text-xs text-gray-500 uppercase font-bold tracking-wider mb-1">Enrolled</p>
            <p className="font-semibold text-gray-800">{comp.registrationCount} Users</p>
          </div>
        </div>

        {message && (
          <div className={`p-4 mb-6 rounded font-medium ${
            message.includes("Success") || message.includes("registered") 
              ? "bg-green-100 text-green-700" 
              : "bg-red-100 text-red-700"
          }`}>
            {message}
          </div>
        )}

        <button 
          onClick={handleRegister}
          disabled={isEnrolled || registering || (user && user.role === "admin")}
          className={`w-full text-white font-bold text-lg py-4 rounded-lg transition shadow-md ${
            user && user.role === "admin"
              ? "bg-gray-500 cursor-not-allowed"
              : isEnrolled
              ? "bg-gray-500 cursor-not-allowed"
              : registering
              ? "bg-blue-400 cursor-wait"
              : "bg-blue-600 hover:bg-blue-700 cursor-pointer"
          }`}
        >
          {user && user.role === "admin"
            ? "Admins Cannot Register"
            : isEnrolled 
            ? "Already Enrolled" 
            : registering 
            ? "Registering..." 
            : user 
            ? "Register Now" 
            : "Login to Register"
          }
        </button>
      </div>
    </div>
  );
}