import React, { useState, useEffect, useContext } from "react";
import api from "../api/axios";
import CompetitionCard from "../components/CompetitionCard";
import { AuthContext } from "../context/AuthContext";
import { Navigate } from "react-router-dom";

export default function Home() {
  const { user } = useContext(AuthContext);
  const [competitions, setCompetitions] = useState([]);
  const [sort, setSort] = useState("trending"); 
  const [category, setCategory] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [dateFilter, setDateFilter] = useState(""); // "upcoming" or "past"

  useEffect(() => {
    // 🧠 SMART SHORTCUT: "Debounce" the search.
    // This waits 500ms after the user stops typing before calling the API,
    // preventing your app from crashing due to too many rapid requests.
    const delayDebounceFn = setTimeout(() => {
      fetchCompetitions();
    }, 500);

    return () => clearTimeout(delayDebounceFn);
  }, [sort, category, searchQuery, dateFilter]);

  const fetchCompetitions = async () => {
    try {
      // Build the dynamic URL with all query parameters
      let url = `/competitions?sort=${sort}`;
      if (category) url += `&category=${category}`;
      if (searchQuery) url += `&search=${encodeURIComponent(searchQuery)}`;
      if (dateFilter) url += `&date=${dateFilter}`;

      console.log("Fetching with URL:", url); // Debug log
      const res = await api.get(url);
      setCompetitions(Array.isArray(res.data) ? res.data : []);
    } catch (err) {
      console.error("API Error or Backend Offline", err);
      setCompetitions([]); // Fallback so app doesn't crash
    }
  };

  // Redirect admins to admin dashboard
  if (user && user.role === "admin") return <Navigate to="/admin" />;

  return (
    <div className="container mx-auto p-6 min-h-screen bg-transparent">
      
      {/* Search & Filter Dashboard */}
     <div className="bg-linear-to-r from-gray-900 via-blue-900 to-gray-900 p-8 rounded-2xl shadow-2xl border border-gray-700 mb-8">
  <h1 className="text-4xl font-extrabold text-transparent bg-clip-text bg-linear-to-r from-blue-400 to-teal-300 mb-6 drop-shadow-lg">
    Discover Your Next Big Win
  </h1>
        
        <div className="flex flex-col md:flex-row gap-4 w-full">
          {/* 1. Text Search Bar */}
          <input 
            type="text"
            placeholder="🔍 Search by title or keyword..."
            className="border border-gray-300 p-3 rounded-lg flex-1 bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 transition"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          
          {/* 2. Category Filter */}
          <select 
            className="border border-gray-300 p-3 rounded-lg w-full md:w-48 bg-white cursor-pointer hover:border-blue-400 transition"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
          >
            <option value="">All Categories</option>
            <option value="design">Design</option>
            <option value="tech">Tech</option>
            <option value="business">Business</option>
          </select>

          {/* 3. Date Filter */}
          <select 
            className="border border-gray-300 p-3 rounded-lg w-full md:w-48 bg-white cursor-pointer hover:border-blue-400 transition"
            value={dateFilter}
            onChange={(e) => setDateFilter(e.target.value)}
          >
            <option value="">All Dates</option>
            <option value="upcoming">Upcoming Deadlines</option>
            <option value="past">Past Deadlines</option>
          </select>

          {/* 4. Sort Options */}
          <select 
            className="border border-gray-300 p-3 rounded-lg w-full md:w-48 bg-white cursor-pointer hover:border-blue-400 transition"
            value={sort}
            onChange={(e) => setSort(e.target.value)}
          >
            <option value="trending">Trending 🔥</option>
            <option value="new">Newest 🆕</option>
          </select>
        </div>
      </div>

      {/* Results Display */}
      {competitions.length === 0 ? (
        <div className="text-center py-20 bg-white rounded-xl shadow-sm border border-gray-100">
          <p className="text-2xl font-bold text-gray-400 mb-2">No competitions found.</p>
          <p className="text-sm text-gray-500">Try adjusting your filters or search terms.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {competitions.map((comp) => (
            <CompetitionCard key={comp._id} comp={comp} />
          ))}
        </div>
      )}
    </div>
  );
}