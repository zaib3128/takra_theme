import React, { useState, useEffect } from "react";
import Calendar from "react-calendar";
import "react-calendar/dist/Calendar.css";
import api from "../api/axios";
import { Link } from "react-router-dom";

export default function CalendarView() {
  const [competitions, setCompetitions] = useState([]);
  const [date, setDate] = useState(new Date());

  useEffect(() => {
    const fetchCompetitions = async () => {
      try {
        const res = await api.get("/competitions");
        setCompetitions(Array.isArray(res.data) ? res.data : []);
      } catch (err) {
        console.error("Error fetching competitions for calendar", err);
      }
    };
    fetchCompetitions();
  }, []);

  // Find competitions that have a deadline on the selected date
  const selectedComps = competitions.filter((comp) => {
    const compDate = new Date(comp.deadline).toDateString();
    return compDate === date.toDateString();
  });

  return (
    <div className="container mx-auto p-6 min-h-screen flex flex-col items-center bg-transparent">
      <h1 className="text-3xl font-bold text-gray-900 mb-8">Deadline Calendar</h1>
      
      <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-100 max-w-4xl w-full grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="flex justify-center">
          <Calendar 
            onChange={setDate} 
            value={date} 
            className="rounded-lg border-none shadow-sm p-4"
          />
        </div>
        
        <div>
          <h2 className="text-xl font-bold mb-4 border-b pb-2">
            Deadlines for {date.toDateString()}
          </h2>
          {selectedComps.length === 0 ? (
            <p className="text-gray-500">No competitions ending on this date.</p>
          ) : (
            <ul className="space-y-4">
              {selectedComps.map((comp) => (
                <li key={comp._id} className="p-4 border rounded bg-blue-50 border-blue-100">
                  <h3 className="font-bold text-blue-900">{comp.title}</h3>
                  <Link to={`/competition/${comp._id}`} className="text-sm text-blue-600 hover:underline mt-2 inline-block">
                    View Details &rarr;
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}