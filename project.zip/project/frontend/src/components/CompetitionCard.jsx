import React, { useContext } from "react";
import { Link } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";

export default function CompetitionCard({ comp }) {
  const { user } = useContext(AuthContext);
  return (
    <div className="bg-white/80 backdrop-blur-md p-6 rounded-xl shadow-md border border-gray-200 hover:shadow-2xl hover:-translate-y-2 transition-all duration-300 flex flex-col group">
      
      {/* Category Badge */}
      <div className="mb-3">
        <span className="inline-block bg-blue-100 text-blue-800 text-xs px-3 py-1 rounded-full font-bold uppercase tracking-wide">
          {comp.category || "General"}
        </span>
      </div>

      {/* Title */}
      <h2 className="text-2xl font-bold text-gray-900 group-hover:text-blue-600 transition-colors mb-2 line-clamp-1">
        {comp.title}
      </h2>

      {/* Description */}
      <p className="text-gray-600 text-sm mb-4 line-clamp-2 grow">
        {comp.description}
      </p>

      {/* Info Details */}
      <div className="space-y-2 mb-6 text-sm text-gray-700 bg-gray-50/50 p-3 rounded-lg border border-gray-100">
        <div className="flex items-center gap-2">
          <span>📅</span>
          <span className="font-medium">Deadline:</span> 
          {new Date(comp.deadline).toLocaleDateString()}
        </div>
        <div className="flex items-center gap-2">
          <span>🏆</span>
          <span className="font-medium">Prizes:</span> 
          {comp.prizes}
        </div>
        <div className="flex items-center gap-2">
          <span>👥</span>
          <span className="font-medium">Enrolled:</span> 
          <span className="text-blue-600 font-bold">{comp.registrationCount}</span>
        </div>
      </div>

      {/* Action Button */}
      <div className="mt-auto">
        {user && user.role === "admin" ? (
          <div className="block w-full text-center bg-gray-500 text-white font-bold py-3 rounded-lg cursor-not-allowed shadow-md">
            Admin: Use Dashboard →
          </div>
        ) : (
          <Link 
            to={`/competition/${comp._id}`} 
            className="block w-full text-center bg-gray-900 text-white font-bold py-3 rounded-lg group-hover:bg-blue-600 transition-colors shadow-md"
          >
            View Details &rarr;
          </Link>
        )}
      </div>
      
    </div>
  );
}