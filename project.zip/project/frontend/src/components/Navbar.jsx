import React, { useContext, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";

export default function Navbar() {
  const { user, logout } = useContext(AuthContext);
  const navigate = useNavigate();
  const [isOpen, setIsOpen] = useState(false); // State for mobile menu

  const handleLogout = () => {
    logout();
    setIsOpen(false);
    navigate("/login");
  };

  // Helper function to close menu when a link is clicked on mobile
  const closeMenu = () => setIsOpen(false);

  return (
    <nav className="bg-gray-900 text-white p-4 shadow-md relative z-50">
      <div className="container mx-auto flex justify-between items-center">
        
        {/* Logo Section */}
        <Link to="/" onClick={closeMenu} className="flex items-center gap-2 text-2xl font-bold tracking-wider text-blue-400">
          <img src="/logo.png" alt="Taakra Logo" className="w-8 h-8 object-contain" />
          TAAKRA
        </Link>

        {/* ========================================= */}
        {/* DESKTOP MENU (Hidden on small screens) */}
        {/* ========================================= */}
        <div className="hidden md:flex gap-4 items-center">
          <Link to="/" className="hover:text-blue-400 transition">Home</Link>
          <Link to="/calendar" className="hover:text-blue-400 transition">Calendar</Link>
          
          {user ? (
            <>
              {user.role === "admin" ? (
                <Link to="/admin" className="hover:text-blue-400 transition">Admin Panel</Link>
              ) : (
                <Link to="/dashboard" className="hover:text-blue-400 transition">Dashboard</Link>
              )}
              <Link to="/profile" className="hover:text-blue-400 transition">Profile</Link>
              <span className="text-gray-400 text-sm border-l border-gray-600 pl-4 ml-2">
                Hello, {user.name}
              </span>
              <button 
                onClick={handleLogout}
                className="bg-red-500 hover:bg-red-600 px-3 py-1 rounded text-sm font-bold transition"
              >
                Logout
              </button>
            </>
          ) : (
            <>
              <Link to="/login" className="hover:text-blue-400 transition">Login</Link>
              <Link to="/register" className="bg-blue-600 hover:bg-blue-700 px-3 py-1 rounded transition">
                Register
              </Link>
            </>
          )}
        </div>

        {/* ========================================= */}
        {/* MOBILE HAMBURGER ICON */}
        {/* ========================================= */}
        <button 
          onClick={() => setIsOpen(!isOpen)} 
          className="md:hidden text-gray-300 hover:text-white focus:outline-none"
        >
          {/* SVG for Hamburger / Close Icon */}
          <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            {isOpen ? (
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
            ) : (
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16" />
            )}
          </svg>
        </button>
      </div>

      {/* ========================================= */}
      {/* MOBILE DROPDOWN MENU */}
      {/* ========================================= */}
      {isOpen && (
        <div className="md:hidden absolute top-full left-0 w-full bg-gray-800 shadow-xl flex flex-col border-t border-gray-700">
          <Link to="/" onClick={closeMenu} className="p-4 border-b border-gray-700 hover:bg-gray-700 hover:text-blue-400 transition">Home</Link>
          <Link to="/calendar" onClick={closeMenu} className="p-4 border-b border-gray-700 hover:bg-gray-700 hover:text-blue-400 transition">Calendar</Link>
          
          {user ? (
            <>
              {user.role === "admin" ? (
                <Link to="/admin" onClick={closeMenu} className="p-4 border-b border-gray-700 hover:bg-gray-700 hover:text-blue-400 transition">Admin Panel</Link>
              ) : (
                <Link to="/dashboard" onClick={closeMenu} className="p-4 border-b border-gray-700 hover:bg-gray-700 hover:text-blue-400 transition">Dashboard</Link>
              )}
              <Link to="/profile" onClick={closeMenu} className="p-4 border-b border-gray-700 hover:bg-gray-700 hover:text-blue-400 transition">Profile</Link>
              <div className="p-4 flex justify-between items-center bg-gray-900">
                <span className="text-gray-400 text-sm">Hello, {user.name}</span>
                <button 
                  onClick={handleLogout}
                  className="bg-red-500 hover:bg-red-600 px-4 py-2 rounded text-sm font-bold transition"
                >
                  Logout
                </button>
              </div>
            </>
          ) : (
            <div className="p-4 flex flex-col gap-3 bg-gray-900">
              <Link to="/login" onClick={closeMenu} className="text-center bg-gray-700 hover:bg-gray-600 py-2 rounded transition">Login</Link>
              <Link to="/register" onClick={closeMenu} className="text-center bg-blue-600 hover:bg-blue-700 py-2 rounded transition">Register</Link>
            </div>
          )}
        </div>
      )}
    </nav>
  );
}