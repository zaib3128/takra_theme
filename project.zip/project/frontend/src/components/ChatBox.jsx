import React, { useState, useEffect, useContext, useRef } from "react";
import { io } from "socket.io-client";
import { AuthContext } from "../context/AuthContext";

export default function ChatBox() {
  const { user } = useContext(AuthContext);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [isOpen, setIsOpen] = useState(false);
  const socketRef = useRef(null);

  useEffect(() => {
    if (isOpen && !socketRef.current) {
      // Connect to Socket server
      const backendUrl = import.meta.env.VITE_API_URL 
        ? import.meta.env.VITE_API_URL.replace('/api', '') 
        : 'http://localhost:5000';
        
      socketRef.current = io(backendUrl);

      socketRef.current.on("message", (message) => {
        setMessages((prev) => [...prev, message]);
      });
    }

    return () => {
      if (socketRef.current && !isOpen) {
        socketRef.current.disconnect();
        socketRef.current = null;
      }
    };
  }, [isOpen]);

  const sendMessage = (e) => {
    e.preventDefault();
    if (input.trim() && socketRef.current) {
      const msgData = {
        user: user ? user.name : "Guest",
        text: input,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      socketRef.current.emit("message", msgData);
      setInput("");
    }
  };

  return (
    <div className="fixed bottom-4 left-4 z-50">
      {!isOpen && (
        <button 
          onClick={() => setIsOpen(true)} 
          className="bg-green-600 text-white px-4 py-3 rounded-full shadow-lg hover:bg-green-700 font-bold flex items-center gap-2 transition"
        >
          💬 Community Chat
        </button>
      )}

      {isOpen && (
        <div className="bg-white w-80 h-96 rounded-lg shadow-2xl border flex flex-col">
          <div className="bg-green-600 text-white p-3 rounded-t-lg flex justify-between items-center font-bold">
            <span>Community Chat</span>
            <button onClick={() => setIsOpen(false)} className="hover:text-gray-200">✖</button>
          </div>
          
          <div className="flex-1 p-3 overflow-y-auto bg-gray-50 flex flex-col gap-2">
            {messages.length === 0 ? (
              <p className="text-center text-gray-400 text-sm mt-4">No messages yet. Say hi!</p>
            ) : (
              messages.map((msg, i) => (
                <div key={i} className={`p-2 rounded text-sm max-w-[85%] ${msg.user === (user?.name || "Guest") ? "bg-green-100 self-end" : "bg-white border self-start"}`}>
                  <span className="font-bold text-xs text-green-700 block mb-1">{msg.user}</span>
                  {msg.text}
                  <span className="text-[10px] text-gray-400 block text-right mt-1">{msg.time}</span>
                </div>
              ))
            )}
          </div>

          <form onSubmit={sendMessage} className="p-2 border-t flex gap-2 bg-white">
            <input 
              type="text" 
              className="flex-1 border rounded px-2 py-1 text-sm focus:outline-none focus:ring-1 focus:ring-green-500" 
              value={input} 
              onChange={(e) => setInput(e.target.value)}
              placeholder="Type a message..." 
            />
            <button type="submit" className="bg-green-600 text-white px-3 rounded text-sm hover:bg-green-700">Send</button>
          </form>
        </div>
      )}
    </div>
  );
}