import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "./context/AuthContext";
import React from "react";

// Pages
import Home from "./pages/Home";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Dashboard from "./pages/Dashboard";
import AdminDashboard from "./pages/AdminDashboard";
import CompetitionDetail from "./pages/CompetitionDetail";
import CalendarView from "./pages/CalendarView";
import Profile from "./pages/Profile";

// Components
import Navbar from "./components/Navbar";
import ChatBox from "./components/ChatBox"; 
import Chatbot from "./components/Chatbot"; 

function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        
        {/* ========================================= */}
        {/* GLOBAL BACKGROUND WATERMARK */}
        {/* ========================================= */}
        <div 
          className="fixed inset-0 z-[-1] bg-center bg-no-repeat opacity-70 pointer-events-none"
          style={{ 
            backgroundImage: "url('/logo.png')",
            backgroundSize: "50%" // You can change this to "60%" or "70%" to make it larger!
          }}
        ></div>
        
        <Navbar />
        
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/admin" element={<AdminDashboard />} />
          <Route path="/competition/:id" element={<CompetitionDetail />} />
          <Route path="/calendar" element={<CalendarView />} />
        </Routes>
        
        <ChatBox />  
        <Chatbot />  
        
      </BrowserRouter>
    </AuthProvider>
  );
}

export default App;